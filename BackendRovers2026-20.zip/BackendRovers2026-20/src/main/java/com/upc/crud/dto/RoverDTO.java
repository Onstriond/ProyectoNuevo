package com.upc.crud.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RoverDTO implements Serializable {
    private Long id;
    @NotBlank(message = "El código es obligatorio")
    @Pattern(regexp = "^ROV[0-9]{4}$", message = "El código debe tener el formato ROV seguido de 4 dígitos (ej. ROV2026)")
    private String codigo;
    @NotBlank(message = "El modelo es obligatorio")
    @Pattern(regexp = "^(SOLAR|NUCLEAR|AUT[OÓ]NOMO|DRONE)$", message = "El modelo debe ser SOLAR, NUCLEAR, AUTÓNOMO o DRONE")
    private String modelo;
    @NotNull(message = "El costo de construcción es obligatorio")
    @DecimalMin(value = "0.0", inclusive = false, message = "El costo de construcción debe ser mayor a cero")
    private Double costoConstruccion;
    @NotNull(message = "La fecha de despliegue es obligatoria")
    private LocalDate fechaDespliegue;
    @NotNull(message = "El estado activo es obligatorio")
    private Boolean estadoActivo;
}
