package com.upc.crud.servicios;

import com.upc.crud.dto.RoverDTO;
import com.upc.crud.entidades.Rover;
import com.upc.crud.interfaces.IRoverService;
import com.upc.crud.repositorios.RoverRepositorio;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class RoverService implements IRoverService {
    // Inyección de dependencias
    @Autowired
    private RoverRepositorio roverRepositorio;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<RoverDTO> listar() {
        return roverRepositorio.findAll().stream().map(rover -> modelMapper.map(rover, RoverDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public RoverDTO insertar(RoverDTO roverDto) {
        // Un registro nuevo siempre se autogenera: se ignora cualquier id enviado
        roverDto.setId(null);
        Rover roverEntidad = modelMapper.map(roverDto, Rover.class);
        Rover guardado = roverRepositorio.save(roverEntidad);
        return modelMapper.map(guardado, RoverDTO.class);
    }

    @Override
    public RoverDTO editar(RoverDTO roverDto) {
        if (roverDto.getId() == null || !roverRepositorio.existsById(roverDto.getId())) {
            throw new NoSuchElementException("Rover con ID " + roverDto.getId() + " no encontrado");
        }
        Rover roverEntidad = modelMapper.map(roverDto, Rover.class);
        Rover guardado = roverRepositorio.save(roverEntidad);
        return modelMapper.map(guardado, RoverDTO.class);
    }

    @Override
    public RoverDTO buscarPorId(Long id) {
        return roverRepositorio.findById(id)
                .map(element -> modelMapper.map(element, RoverDTO.class))
                .orElseThrow(() -> new NoSuchElementException("Rover con ID " + id + " no encontrado"));
    }

    @Override
    public void eliminar(Long id) {
        if (!roverRepositorio.existsById(id)) {
            throw new NoSuchElementException("Rover no encontrado con ID: " + id);
        }
        roverRepositorio.deleteById(id);
    }
}
