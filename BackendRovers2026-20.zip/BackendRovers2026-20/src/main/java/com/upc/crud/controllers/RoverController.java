package com.upc.crud.controllers;

import com.upc.crud.dto.RoverDTO;
import com.upc.crud.interfaces.IRoverService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200",
        allowCredentials = "true",
        exposedHeaders = "Authorization")
@RequestMapping("/api")
public class RoverController {
    @Autowired
    private IRoverService roverService;

    @GetMapping("/rovers")
    public List<RoverDTO> listarRovers() {
        log.debug("Lista de rovers");
        return roverService.listar();
    }

    @PostMapping("/rover")
    public ResponseEntity<RoverDTO> registrarRover(@Valid @RequestBody RoverDTO roverDto) {
        // Si la validación falla, este código no se ejecutará.
        // Spring lanzará una excepción MethodArgumentNotValidException
        RoverDTO registrado = roverService.insertar(roverDto);
        log.info("Registrado rover: {}", registrado.getId());
        return ResponseEntity.ok(registrado);
    }

    @PutMapping("/rover")
    public ResponseEntity<RoverDTO> editarRover(@Valid @RequestBody RoverDTO roverDto) {
        return ResponseEntity.ok(roverService.editar(roverDto));
    }

    @GetMapping("/rover/{id}")
    public ResponseEntity<RoverDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(roverService.buscarPorId(id));
    }

    @DeleteMapping("/rover/{id}")
    public void eliminar(@PathVariable Long id) {
        roverService.eliminar(id);
    }
}
