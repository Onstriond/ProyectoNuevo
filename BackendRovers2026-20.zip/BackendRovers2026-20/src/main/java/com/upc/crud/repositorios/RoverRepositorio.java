package com.upc.crud.repositorios;

import com.upc.crud.entidades.Rover;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoverRepositorio extends JpaRepository<Rover, Long> {
}
