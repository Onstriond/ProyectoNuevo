package com.upc.crud.interfaces;

import com.upc.crud.dto.RoverDTO;

import java.util.List;

public interface IRoverService {
    List<RoverDTO> listar();
    RoverDTO insertar(RoverDTO rover);
    RoverDTO editar(RoverDTO rover);
    RoverDTO buscarPorId(Long id);
    void eliminar(Long id);
}
