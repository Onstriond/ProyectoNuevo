INSERT INTO rover (codigo, modelo, costo_construccion, fecha_despliegue, estado_activo) VALUES ('ROV2026', 'SOLAR', 2500000.0, '2024-06-12', true);
INSERT INTO rover (codigo, modelo, costo_construccion, fecha_despliegue, estado_activo) VALUES ('ROV2027', 'NUCLEAR', 7800000.5, '2022-11-05', true);
INSERT INTO rover (codigo, modelo, costo_construccion, fecha_despliegue, estado_activo) VALUES ('ROV2028', 'AUTÓNOMO', 4300000.0, '2023-03-19', false);
INSERT INTO rover (codigo, modelo, costo_construccion, fecha_despliegue, estado_activo) VALUES ('ROV2029', 'DRONE', 950000.75, '2025-02-08', true);
INSERT INTO rover (codigo, modelo, costo_construccion, fecha_despliegue, estado_activo) VALUES ('ROV2030', 'SOLAR', 2750000.0, '2021-08-23', false);
